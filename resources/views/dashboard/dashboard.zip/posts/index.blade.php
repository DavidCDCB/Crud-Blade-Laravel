@extends('dashboard.master')

@section('content')
	<h6>Listar publicacion</h6>
@endsection
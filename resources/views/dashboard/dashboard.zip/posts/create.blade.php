@extends('dashboard.master')
@section('content')
	<h6>Crear publicacion</h6>
@endsection